//
// Created by Aleh Rudneu on 17.01.24.
//// по русски изза буста

#include "server.hxx"//вспомогательная функция для сервера
#include <iostream>// то есть если закрываю игру, она выводит сообщение

void main_server::reportReturn(sys::error_code ec, std::string_view what){
    std::cout << what << ": "sv << ec.message() << '\n';
}