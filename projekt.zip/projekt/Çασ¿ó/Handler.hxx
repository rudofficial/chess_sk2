//обработка сообщений поступающих от клиента, нп он нажал криэйт гейм, конект, мув
// Created by Aleh Rudneu on 24.01.24.
//

#ifndef HANDLER_HXX
#define HANDLER_HXX
#include <random>
#include "model.hxx"
#include "server.hxx"
#include "su_map.hxx"

namespace main_server {

    inline Message &Message::operator<<(const Piece &piece) {
        *this << piece.getType() << piece.getColor();
        return *this;
    }

    inline Message &Message::operator>>(Piece &piece) {
        Piece::Type type{};
        Piece::Color color{};
        *this >> type >> color;
        piece = {type, color};
        return *this;
    }
    
    
    //комуникац мжду сервером иклинтом


    class Handler {
    private:
        struct Game {//хранит данн о одной игре
            mutable std::chrono::steady_clock::time_point gameCreated{};//время созд игры
            mutable std::weak_ptr<SessionBase> p1{};//игрокодин
            mutable std::weak_ptr<SessionBase> p2{};//игрокдва
            mutable ChessGame game{};//обхект озн стан игры
        };

        //мгеймс-карта показыв идентифик игры на объкт гейм 

        SUMap<int, Game> m_games{}; 

    public:
        template<typename Send> //вызов при получ сообщ клиента
        void operator()(Message &&req, std::shared_ptr<SessionBase> ptr, Send &&send) {
            send(std::move(getResponse(std::move(req), ptr)));
        }


        //отв на получ сообщ от клиента
    private:
        Message getResponse(Message &&request, std::shared_ptr<SessionBase> ptr) {
            Message response{};
            switch (request.msgType) { //тут прописана логика игры
                case MessageType::create_game: {// типо создание игры
                    response.msgType = MessageType::create_game;//подкл к сущ игре
                    while (true) {//выполнение движения
                        int number{generateNumber()};
                        if (m_games.contains(number))
                            continue;
                        m_games.setValue(number, {std::chrono::steady_clock::now(), ptr, {}, {}});
                        response << number;
                        ptr->gameID = number;
                        break;
                    }
                    break;
                }

                case MessageType::connect_to_other_game: {
                    response.msgType = MessageType::connect_to_other_game;
                    int id{};
                    request >> id;
                    if (m_games.contains(id) && !m_games.getValue(id).p2.lock()) {
                        m_games.getValue(id).p2 = ptr;
                        response << true;
                        response << id;
                        response << m_games.getValue(id).game.getBoard().getBoard();
                        ptr->gameID = id;
                        Message responseForPlyaer1{};
                        responseForPlyaer1.msgType = MessageType::connect_to_your_game;
                        responseForPlyaer1 << m_games.getValue(id).game.getBoard().getBoard();
                        m_games.getValue(id).p1.lock()->writeOnly(std::move(responseForPlyaer1));
                    }
                    else
                        response << false;


                    break;
                }

                case MessageType::move: {
                    if (ptr->gameID.has_value()) {
                        const auto &[gameCreated, p1, p2, game]{m_games.getValue(*ptr->gameID)};
                        if (ptr == (game.isWhiteMove() ? p1.lock() : p2.lock())) {
                            int fromRow{};
                            int fromCol{};
                            int toRow{};
                            int toCol{};

                            request >> fromCol >> fromRow >> toCol >> toRow;

                            auto answer{game.move(fromRow, fromCol, toRow, toCol)};
                            Message moveResponse{};
                            moveResponse.msgType = MessageType::move;
                            moveResponse << !answer.has_value();
                            if (!answer)
                                moveResponse << game.getBoard().getBoard();
                            auto copy{moveResponse};
                            p1.lock()->writeOnly(std::move(moveResponse));
                            p2.lock()->writeOnly(std::move(copy));
                        }
                    }
                    response.msgType = MessageType::bad_move;
                    break;
                }
            }

            return response;
        }//лосовы нумер для подкл к игре, ее идентиф

        static int generateNumber() {
            static std::mt19937_64 eng{std::random_device{}()};
            return std::uniform_int_distribution{}(eng);
        }
    };
} // namespace main_server

#endif //HANDLER_HXX
