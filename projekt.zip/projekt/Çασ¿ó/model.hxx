//тут чисто логика шахмат, как они ходят, чей ход и можно ли ходить
// Created by Aleh Rudneu on 17.01.24.
//

#ifndef MODEL_HXX
#define MODEL_HXX
#include <array>
#include <cmath>
#include <cstdint>
#include <optional>
#include <string>

class Piece final {
public://мои фигуры
    enum class Type : std::uint8_t {
        not_a_piece,
        pawn,
        knight,
        bishop,
        rook,
        queen,
        king,
    };//цвет фиг

    enum class Color : std::uint8_t {
        white,
        black,
    };

private:
    Type piece_;
    Color color_;

public:
    Piece() = default;//получ о цвет и тип фиг
    Piece(const Type piece, const Color color) : piece_{piece}, color_{color} {}

    [[nodiscard]] Type getType() const noexcept { return piece_; }

    [[nodiscard]] Color getColor() const noexcept { return color_; }
};

//проверк позиц, правильн ли шаг и выполн шага
//моя доска

class Board final {
private:
    std::array<std::array<Piece, 8>, 8> board_{};
    
public:
    void initializeBoard() {
        // Place white pieces
        board_[0][0] = Piece(Piece::Type::rook, Piece::Color::black);
        board_[0][1] = Piece(Piece::Type::knight, Piece::Color::black);
        board_[0][2] = Piece(Piece::Type::bishop, Piece::Color::black);
        board_[0][3] = Piece(Piece::Type::queen, Piece::Color::black);
        board_[0][4] = Piece(Piece::Type::king, Piece::Color::black);
        board_[0][5] = Piece(Piece::Type::bishop, Piece::Color::black);
        board_[0][6] = Piece(Piece::Type::knight, Piece::Color::black);
        board_[0][7] = Piece(Piece::Type::rook, Piece::Color::black);

        for (int i = 0; i < 8; ++i)
            board_[1][i] = Piece(Piece::Type::pawn, Piece::Color::black);

        // Place black pieces
        board_[7][0] = Piece(Piece::Type::rook, Piece::Color::white);
        board_[7][1] = Piece(Piece::Type::knight, Piece::Color::white);
        board_[7][2] = Piece(Piece::Type::bishop, Piece::Color::white);
        board_[7][3] = Piece(Piece::Type::queen, Piece::Color::white);
        board_[7][4] = Piece(Piece::Type::king, Piece::Color::white);
        board_[7][5] = Piece(Piece::Type::bishop, Piece::Color::white);
        board_[7][6] = Piece(Piece::Type::knight, Piece::Color::white);
        board_[7][7] = Piece(Piece::Type::rook, Piece::Color::white);

        for (int i = 0; i < 8; ++i)
            board_[6][i] = Piece(Piece::Type::pawn, Piece::Color::white);

        // Fill the empty spaces with null pieces
        for (int i = 2; i < 6; ++i)
            for (int j = 0; j < 8; ++j)
                board_[i][j] = Piece(Piece::Type::not_a_piece, Piece::Color::black);
        // Null piece, can be an empty placeholder
    }

    [[nodiscard]] std::pair<int, int> getKing(Piece::Color color) const noexcept {
        for (std::size_t i{}; i < board_.size(); ++i)
            for (std::size_t j{}; j < board_.size(); ++j)
                if (const auto &p{board_[i][j]}; p.getType() == Piece::Type::king && color == p.getColor())
                    return {i, j};

        return {-1, -1};
    }

    [[nodiscard]] const auto &getBoard() const noexcept { return board_; }

    [[nodiscard]] bool hasCheck(int row, int col) const noexcept {
        const Piece &piece{board_[row][col]};
        if (piece.getType() == Piece::Type::not_a_piece)
            return false;

        const Piece::Color color{piece.getColor()};

        for (std::size_t i{}; i < board_.size(); ++i)
            for (std::size_t j{}; j < board_[i].size(); ++j) {
                const auto &p{board_[i][j]};
                if (p.getType() == Piece::Type::not_a_piece)
                    continue;
                if (p.getColor() == color)
                    continue;
                if (i == row && j == col)
                    continue;

                bool isValid{isValidMove(i, j, row, col)};
                if (!isValid)
                    return true;
            }

        return false;
    }

    void move(int fromRow, int fromCol, int toRow, int toCol) {
        board_[toRow][toCol] = board_[fromRow][fromCol];
        board_[fromRow][fromCol] = Piece{Piece::Type::not_a_piece, Piece::Color::black};
    }

    [[nodiscard]] bool isValidMove(int fromRow, int fromCol, int toRow, int toCol, bool checkHasCheck = false) const {
        // Check if the 'from' and 'to' coordinates are within the board boundaries
        if (fromRow < 0 || fromRow > 7 || fromCol < 0 || fromCol > 7 || toRow < 0 || toRow > 7 || toCol < 0 ||
            toCol > 7)
            return false;

        const Piece &fromPiece = board_[fromRow][fromCol];
        const Piece &toPiece = board_[toRow][toCol];

        // Check if there is a piece at the 'from' position
        if (fromPiece.getType() == Piece::Type::not_a_piece)
            return false;

        std::optional<bool> result{};
        std::optional<bool> check{};
        if (checkHasCheck) {
            auto kingPos{getKing(fromPiece.getColor())};
            check = hasCheck(kingPos.first, kingPos.second);
        }

        // Pawn movement logic
        if (fromPiece.getType() == Piece::Type::pawn) {
            int direction = (fromPiece.getColor() == Piece::Color::white) ? -1 : 1;
            int startRow = (fromPiece.getColor() == Piece::Color::white) ? 6 : 1;

            // Normal move
            if (fromCol == toCol && toRow == fromRow + direction && toPiece.getType() == Piece::Type::not_a_piece)
                result = true;

            // First move: 2 squares
            else if (fromCol == toCol && toRow == fromRow + 2 * direction && fromRow == startRow &&
                     toPiece.getType() == Piece::Type::not_a_piece &&
                     board_[fromRow + direction][fromCol].getType() == Piece::Type::not_a_piece) {
                result = true;
            }

            // Capture move
            else if (std::abs(fromCol - toCol) == 1 && toRow == fromRow + direction &&
                     toPiece.getType() != Piece::Type::not_a_piece && toPiece.getColor() != fromPiece.getColor())
                result = true;
        }

        // Knight movement logic
        else if (fromPiece.getType() == Piece::Type::knight) {
            // Calculate the distance moved in both the row and column
            int rowDistance = abs(toRow - fromRow);
            int colDistance = abs(toCol - fromCol);

            // Check for L-shape movement (2 squares in one direction and 1 square in another)
            if ((rowDistance == 2 && colDistance == 1) || (rowDistance == 1 && colDistance == 2)) {
                // Check if the destination square is either empty or occupied by an opponent's piece
                if (toPiece.getType() == Piece::Type::not_a_piece || toPiece.getColor() != fromPiece.getColor())
                    result = true;
            }
        }

        // Bishop movement logic
        else if (fromPiece.getType() == Piece::Type::bishop) {
            int rowDistance = abs(toRow - fromRow);
            int colDistance = abs(toCol - fromCol);

            // Check if the move is diagonal (distances should be equal)
            if (rowDistance == colDistance) {
                // Determine the direction of movement
                int rowDirection = (toRow - fromRow) / rowDistance;
                int colDirection = (toCol - fromCol) / colDistance;

                // Check each square along the diagonal for other pieces
                for (int i = 1; i < rowDistance; ++i) {
                    if (board_[fromRow + i * rowDirection][fromCol + i * colDirection].getType() !=
                        Piece::Type::not_a_piece) {
                        result = false; // Another piece is blocking the path
                    }
                }

                // Check if the destination square is either empty or occupied by an opponent's piece
                if (toPiece.getType() == Piece::Type::not_a_piece || toPiece.getColor() != fromPiece.getColor()) {
                    if (!result)
                        result = true;
                }
            }
        }

        // Rook movement logic
        else if (fromPiece.getType() == Piece::Type::rook) {
            // Check if the move is either horizontal or vertical
            if (fromRow == toRow || fromCol == toCol) {
                int rowDirection = (toRow == fromRow) ? 0 : ((toRow > fromRow) ? 1 : -1);
                int colDirection = (toCol == fromCol) ? 0 : ((toCol > fromCol) ? 1 : -1);

                // Start checking from the next square in the direction of movement until the destination
                for (int i = 1; i < std::max(abs(toRow - fromRow), abs(toCol - fromCol)); ++i) {
                    if (board_[fromRow + i * rowDirection][fromCol + i * colDirection].getType() !=
                        Piece::Type::not_a_piece) {
                        result = false; // Another piece is blocking the path
                    }
                }

                // Check if the destination square is either empty or occupied by an opponent's piece
                if (toPiece.getType() == Piece::Type::not_a_piece || toPiece.getColor() != fromPiece.getColor()) {
                    if (!result)
                        result = true;
                }
            }
        }

        // Queen movement logic
        else if (fromPiece.getType() == Piece::Type::queen) {
            int rowDistance = abs(toRow - fromRow);
            int colDistance = abs(toCol - fromCol);

            // Check if the move is either horizontal, vertical, or diagonal
            if (fromRow == toRow || fromCol == toCol || rowDistance == colDistance) {
                int rowDirection = (toRow == fromRow) ? 0 : ((toRow > fromRow) ? 1 : -1);
                int colDirection = (toCol == fromCol) ? 0 : ((toCol > fromCol) ? 1 : -1);

                // Start checking from the next square in the direction of movement until the destination
                for (int i = 1; i < std::max(rowDistance, colDistance); ++i) {
                    if (board_[fromRow + i * rowDirection][fromCol + i * colDirection].getType() !=
                        Piece::Type::not_a_piece) {
                        result = false; // Another piece is blocking the path
                    }
                }

                // Check if the destination square is either empty or occupied by an opponent's piece
                if (toPiece.getType() == Piece::Type::not_a_piece || toPiece.getColor() != fromPiece.getColor()) {
                    if (!result)
                        result = true;
                }
            }
        }

        // King movement logic
        if (fromPiece.getType() == Piece::Type::king) {
            int rowDistance = abs(toRow - fromRow);
            int colDistance = abs(toCol - fromCol);

            // Check if the move is exactly one square in any direction
            if ((rowDistance == 1 || rowDistance == 0) && (colDistance == 1 || colDistance == 0) &&
                !(rowDistance == 0 && colDistance == 0)) {
                // Check if the destination square is either empty or occupied by an opponent's piece
                if (toPiece.getType() == Piece::Type::not_a_piece || toPiece.getColor() != fromPiece.getColor()) {
                    result = true;
                }
            }
        }


        if (*result && check && *check) {
            auto board{*this};
            board.move(fromRow, fromCol, toRow, toCol);
            auto kingPos{board.getKing(fromPiece.getColor())};
            return !board.hasCheck(kingPos.first, kingPos.second);
        }

        return *result;
    }
};//озн стан гры в шахы

class ChessGame final {
private://объ борд и флага чы рух для белфиг
    Board board_{};
    bool m_isWhiteMove{true};
    //актуал стан,выполн руху, проверк чья очеред
    //проверк законч ли игра и побдитля
public:
    ChessGame() { board_.initializeBoard(); }

    [[nodiscard]] const Board &getBoard() const noexcept { return board_; }

    std::optional<std::string> move(int fromRow, int fromCol, int toRow, int toCol) {
        if (board_.getBoard()[fromRow][fromCol].getColor() == Piece::Color::white && !m_isWhiteMove)
            return "Not u move";
        if (!board_.isValidMove(fromRow, fromCol, toRow, toCol))
            return "Invalid move";
        board_.move(fromRow, fromCol, toRow, toCol);
        m_isWhiteMove = !m_isWhiteMove;
        return {};
    }

    [[nodiscard]] bool isWhiteMove() const noexcept { return m_isWhiteMove; }

    [[nodiscard]] bool isGameEnd() const noexcept {}

    [[nodiscard]] Piece::Color getWinner() const noexcept {}
};


#endif //MODEL_HXX
