//тут система сообщений, сам сервер здесь. 
// Created by Aleh Rudneu on 17.01.24.
//

#ifndef SERVER_HXX
#define SERVER_HXX
#include <boost/asio.hpp>

class Piece;

namespace main_server {
    namespace net = boost::asio;
    namespace sys = boost::system;
    using net::ip::tcp;
    using namespace std::literals;

    //разные типы сообщ мжду клиентсервер
    enum class MessageType : int {
        create_game,
        connect_to_your_game,
        connect_to_other_game,
        move,
        bad_move,
        game_end,
    };


    //озн сообщ, хранит тип сообщ,размер
    //инф о данных,всказник помоцничы
    struct Message {
        MessageType msgType{};
        std::size_t size{};
        std::vector<std::uint8_t> data{};
        std::size_t pointer{};

        [[nodiscard]] std::vector<char> Serialize() const {
            std::vector<char> vector{};
            vector.resize(sizeof(msgType) + sizeof(size) + size);
            std::memcpy(vector.data(), &msgType, sizeof(msgType));
            std::memcpy(vector.data() + sizeof(msgType), &size, sizeof(size));
            if (size > 0)
                std::memcpy(vector.data() + sizeof(msgType) + sizeof(size), data.data(), size);
            return vector;
        }

        template<typename T, typename = std::enable_if<std::is_fundamental_v<T>>>
        Message &operator<<(const T &value) {
            auto newSize{size + sizeof(value)};
            data.resize(newSize);
            std::memcpy(data.data() + size, &value, sizeof(value));
            size = newSize;
            return *this;
        }

        Message &operator<<(const std::string &str) {
            *this << str.size();
            auto newSize{size + str.size()};
            data.resize(newSize);
            std::memcpy(data.data() + size, str.data(), str.size());
            size = newSize;

            return *this;
        }

        template<typename T>
        Message &operator<<(const std::vector<T> &vec) {
            *this << vec.size();
            for (const auto &el: vec)
                *this << el;

            return *this;
        }

        Message &operator<<(const Piece &piece);

        template<typename T, typename = std::enable_if<std::is_fundamental_v<T>>>
        Message &operator>>(T &value) {
            std::memcpy(&value, data.data() + pointer, sizeof(value));
            pointer += sizeof(value);
            return *this;
        }

        Message &operator>>(std::string &str) {
            std::size_t strSize{};
            *this >> strSize;
            str.resize(strSize);
            std::memcpy(str.data(), data.data() + pointer, strSize);
            pointer += strSize;
            return *this;
        }

        template<typename T>
        Message &operator>>(std::vector<T> &vec) {
            std::size_t vecSize{};
            *this >> vecSize;
            vec.resize(vecSize);
            for (auto &el: vec)
                *this >> el;

            return *this;
        }

        Message &operator>>(Piece &piece);
    };



    //функц для рапорт ошибок
    //сисерор-проверка есть ли ошбка и пишет комуникат

    void reportReturn(sys::error_code ec, std::string_view what); 

    //отв за подкл с клиент, чит и запис данных

    class SessionBase {
    private:
        tcp::socket m_socket;   //гнездотсп,таймер, запрос в дан момент
        net::steady_timer m_timer; 
        Message m_requestMessage{};

    public:
        SessionBase(const SessionBase &) = delete;

        SessionBase &operator=(const SessionBase &) = delete;

        //урхамя сесье, чит тып вядомсти
        void run() { net::dispatch(m_socket.get_executor(), std::bind_front(&SessionBase::readType, getSharedThis())); } 

        virtual std::shared_ptr<SessionBase> getSharedThis() = 0;



        void writeOnly(Message &&response) {
            auto safeResponse{std::make_shared<std::vector<char>>(response.Serialize())};
            net::dispatch(m_socket.get_executor(), [safeResponse, self = getSharedThis()]() mutable {
                net::async_write(self->m_socket, net::buffer(*safeResponse),//запись сообщ до клиент,но потверж не ждет
                                 [safeResponse, s = self](sys::error_code ec, std::size_t bytesWritten) {});
            });
        }
        
        //хран айди,но опц
        std::optional<int> gameID{};

    protected:
        explicit SessionBase(tcp::socket &&socket) : m_socket{std::move(socket)}, m_timer{m_socket.get_executor()} {}

        ~SessionBase() = default;

        void write(Message &&response) {
            auto safeResponce{std::make_shared<std::vector<char>>(std::move(response.Serialize()))};

            net::async_write(m_socket, net::buffer(*safeResponce),
                             [self = getSharedThis(), safeResponce](sys::error_code ec, std::size_t bytesWritten) {
                                 self->onWrite(ec, bytesWritten);
                             });
        }

    private:
        void readType() {
            m_requestMessage = {};
            // m_stream.expires_after(30s);

            net::async_read(m_socket, net::buffer(&m_requestMessage.msgType, sizeof(m_requestMessage.msgType)),
                            std::bind_front(&SessionBase::onReadType, getSharedThis()));
        }

        void onReadType(sys::error_code ec, [[maybe_unused]] std::size_t bytesRead) {
            if (ec)
                return reportReturn(ec, "readType"sv);

            readSize();
        }

        void readSize() {
            net::async_read(m_socket, net::buffer(&m_requestMessage.size, sizeof(m_requestMessage.size)),
                            std::bind_front(&SessionBase::onReadSize, getSharedThis()));
        }

        void onReadSize(sys::error_code ec, [[maybe_unused]] std::size_t bytesRead) {
            if (ec)
                return reportReturn(ec, "readSize"sv);

            m_requestMessage.data.resize(m_requestMessage.size);
            readData();
        }

        void readData() {
            net::async_read(m_socket, net::buffer(m_requestMessage.data.data(), m_requestMessage.size),
                            std::bind_front(&SessionBase::onReadData, getSharedThis()));
        }

        void onReadData(sys::error_code ec, [[maybe_unused]] std::size_t bytesRead) {
            if (ec)
                return reportReturn(ec, "readData"sv);

            handleRequest(std::move(m_requestMessage));
        }

        void onWrite(sys::error_code ec, [[maybe_unused]] std::size_t bytesWritten) {
            if (ec)
                return reportReturn(ec, "write"sv);
            readType();
        }

        void close() {
            sys::error_code ec;
            m_socket.shutdown(m_socket.shutdown_send, ec);
        }
        virtual void handleRequest(Message &&request) = 0;
    };
    
    
    //озн сесию клиент, отв за жаданя клиента и отп сообщ

    template<typename RequestHandler> 
    class Session final : public SessionBase, public std::enable_shared_from_this<Session<RequestHandler>> {
    private:
        RequestHandler m_handleRequest;

    public:
        template<typename Handler>
        Session(tcp::socket &&socket, Handler &&handleRequest) :
            SessionBase{std::move(socket)}, m_handleRequest{std::forward<Handler>(handleRequest)} {}

        std::shared_ptr<SessionBase> getSharedThis() override { return this->shared_from_this(); }

    private:
        void handleRequest(Message &&request) override {
            m_handleRequest(std::move(request), getSharedThis(),
                            [self = this->shared_from_this()](auto &&response) { self->write(std::move(response)); });
        }
    };

    //объкт наслухацы на нов подкл и дел нов сесию

    template<typename RequestHandler>
    class Listener : public std::enable_shared_from_this<Listener<RequestHandler>> {
    private:
        net::io_context &m_ioc;
        tcp::acceptor m_acceptor{net::make_strand(m_ioc)};
        RequestHandler m_handleRequest;

    public:
        template<typename Handler>
        Listener(net::io_context &ioc, const tcp::endpoint &endpoint, Handler &&handleRequest) :
            m_ioc{ioc}, m_handleRequest{std::forward<Handler>(handleRequest)} {
            m_acceptor.open(endpoint.protocol());
            m_acceptor.set_option(net::socket_base::reuse_address(true));
            m_acceptor.bind(endpoint);
            m_acceptor.listen(net::socket_base::max_listen_connections);
        }

        void run() { doAccept(); }

    private:
        void doAccept() {
            m_acceptor.async_accept(net::make_strand(m_ioc),
                                    std::bind_front(&Listener::onAccept, this->shared_from_this()));
        }

        void onAccept(sys::error_code ec, tcp::socket socket) {
            if (ec)
                return reportReturn(ec, "accept"sv);

            asyncSessionStart(std::move(socket));
            doAccept();
        }

        void asyncSessionStart(tcp::socket &&socket) {
            std::make_shared<Session<RequestHandler>>(std::move(socket), m_handleRequest)->run();
        }
    };

    //дел объкт наслухацы на нов подкл жаданя клиента

    template<typename RequstHandler>
    void serveHttp(net::io_context &ioc, const tcp::endpoint &endpoint, RequstHandler &&handler) {
        using MyListener = Listener<std::decay_t<RequstHandler>>;
        std::make_shared<MyListener>(ioc, endpoint, std::forward<RequstHandler>(handler))->run();
    }
} // namespace main_server

#endif //SERVER_HXX
