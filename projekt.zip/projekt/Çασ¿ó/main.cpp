//��� ����������� �����, ������� ������ � ��������� ���
#include <iostream>

#include "Handler.hxx"
#include "server.hxx"


//���� � ��� �������
template<typename Fn>
void RunWorkers(unsigned n, const Fn &fn) {
    n = std::max(1u, n);
    std::vector<std::jthread> workers;
    workers.reserve(n - 1);

    while (--n)
        workers.emplace_back(fn);

    fn();
}

namespace net = boost::asio;
using namespace std::literals;

int main() {
    try {
        const auto address{net::ip::make_address("0.0.0.0"sv)};
        constexpr std::uint16_t port{3333};

        const unsigned num_threads = std::thread::hardware_concurrency();
        net::io_context ioc(num_threads);

        net::signal_set signals{ioc, SIGINT, SIGTERM};
        signals.async_wait([&ioc](boost::system::error_code ec, [[maybe_unused]] int signalNumber) {
            if (!ec)
                ioc.stop();
        });

        main_server::Handler handler{};


        main_server::serveHttp(ioc, {address, port},
                               [&handler](auto &&req, std::shared_ptr<main_server::SessionBase> ptr, auto &&send) {
                                   handler(std::forward<decltype(req)>(req), ptr, std::forward<decltype(send)>(send));
                               });

        std::cout << "Server has started..."sv << std::endl;

        RunWorkers(std::max(1u, num_threads), [&ioc] { ioc.run(); });
    }
    catch (const std::exception &ex) {
        std::cerr << ex.what() << std::endl;
        return EXIT_FAILURE;
    }
}
