// Created by Aleh Rudneu on 13.11.23.
//

#ifndef PPHOOK_SERVER_SU_MAP_HXX
#define PPHOOK_SERVER_SU_MAP_HXX
#include <boost/asio.hpp>

#include <future>//синхронизированная карта, карта эта хранит все игры
#include <memory>
#include <ranges>//если параллельно две игры идут, она их хранит
#include <unordered_map>

namespace net = boost::asio;
namespace sys = boost::system;
using namespace std::literals;

template <typename Key,
          typename Value,
          typename Hash = std::hash<Key>,
          typename Equal = std::equal_to<Key>>
class SUMap final
{
private:
    std::unordered_map<Key, Value, Hash, Equal> m_map{};
    mutable std::mutex m_mutex{};

public:
    SUMap() = default;

    void erase(const Key& key) {
        std::unique_lock lock{ m_mutex };
        m_map.erase(key);
    }

    void setValue(const Key& key, const Value& value) {
        std::unique_lock lock{ m_mutex };
        m_map[key] = value;
    }

    const Value& getValue(const Key& key) const {
        std::unique_lock lock{ m_mutex };
        return m_map.at(key);
    }

    bool contains(const Key& key) const noexcept {
        std::unique_lock lock{ m_mutex };
        return m_map.contains(key);
    }

    std::vector<Key> getKeys() const {
        std::vector<Key> vec{};
        std::unique_lock lock{ m_mutex };
        for (const auto& key : m_map | std::views::keys)
            vec.emplace_back(key);
        return vec;
    }

    auto begin() { return m_map.begin(); }
    auto end() { return m_map.end(); }
    auto cbegin() const { return m_map.cbegin(); }
    auto cend() const { return m_map.cend(); }
};

#endif // PPHOOK_SERVER_SU_MAP_HXX
